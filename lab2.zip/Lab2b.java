import java.util.PriorityQueue;


public class Lab2b {
  public static double[] simplifyShape(double[] poly, int k)
  {
      // TODO
  }
}
